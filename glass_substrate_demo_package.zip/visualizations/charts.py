
import matplotlib.pyplot as plt
from gsp_core.storage import load_chain
from gsp_core.verification import verify_chain
from datetime import datetime

def show_chain_growth():
    chain = load_chain()
    times = [datetime.fromisoformat(e["timestamp"]) for e in chain]
    counts = list(range(1, len(chain) + 1))

    plt.figure()
    plt.plot(times, counts)
    plt.title("Glass Substrate Chain Growth")
    plt.xlabel("Time")
    plt.ylabel("Attestations")
    plt.xticks(rotation=45)
    plt.tight_layout()
    plt.show()

def show_integrity():
    integrity = verify_chain()
    plt.figure()
    plt.plot(range(len(integrity)), integrity)
    plt.title("Chain Integrity Status")
    plt.xlabel("Event Index")
    plt.ylabel("Integrity (1 = Valid)")
    plt.ylim(-0.1, 1.1)
    plt.show()
