
import hashlib
import json
from datetime import datetime
from uuid import uuid4
from .storage import load_chain, save_chain

def compute_hash(payload: dict) -> str:
    payload_string = json.dumps(payload, sort_keys=True).encode()
    return hashlib.sha256(payload_string).hexdigest()

def seal_event(user_id, event_type, risk_level, policy_version):
    chain = load_chain()
    previous_hash = chain[-1]["hash"] if chain else None

    event = {
        "event_id": str(uuid4()),
        "timestamp": datetime.utcnow().isoformat(),
        "user_id": user_id,
        "event_type": event_type,
        "risk_level": risk_level,
        "policy_version": policy_version,
        "previous_hash": previous_hash
    }

    event["hash"] = compute_hash(event)
    chain.append(event)
    save_chain(chain)

    return event
