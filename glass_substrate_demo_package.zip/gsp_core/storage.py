
import json
import os

DATA_FILE = "data/storage.json"

def load_chain():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as f:
        return json.load(f)

def save_chain(chain):
    with open(DATA_FILE, "w") as f:
        json.dump(chain, f, indent=2)
