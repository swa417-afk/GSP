
from .storage import load_chain
from .engine import compute_hash

def verify_chain():
    chain = load_chain()
    integrity_map = []

    for i, event in enumerate(chain):
        stored_hash = event["hash"]
        payload = event.copy()
        del payload["hash"]

        recomputed = compute_hash(payload)

        valid = stored_hash == recomputed
        if i > 0:
            valid = valid and event["previous_hash"] == chain[i - 1]["hash"]

        integrity_map.append(1 if valid else 0)

    return integrity_map
