
from .storage import load_chain
from .verification import verify_chain

def reconstruct_event(event_id):
    chain = load_chain()
    integrity = verify_chain()

    for event in chain:
        if event["event_id"] == event_id:
            status = "ADMISSIBLE" if all(integrity) else "INVALID"

            return {
                "Event ID": event["event_id"],
                "User": event["user_id"],
                "Event Type": event["event_type"],
                "Risk Level": event["risk_level"],
                "Policy Version": event["policy_version"],
                "Timestamp": event["timestamp"],
                "Chain Integrity": all(integrity),
                "Evidence Status": status
            }

    return None
