
from gsp_core.engine import seal_event
from gsp_core.reconstruction import reconstruct_event
from gsp_core.verification import verify_chain

def run_terminal():
    while True:
        print("\nGLASS SUBSTRATE TERMINAL")
        print("1. Seal Event")
        print("2. Verify Chain")
        print("3. Reconstruct Event")
        print("4. Exit")

        choice = input("Select: ")

        if choice == "1":
            event = seal_event("analyst_42", "HIGH_RISK_QUERY", "HIGH", "v1.0")
            print("Event Sealed:", event["event_id"])

        elif choice == "2":
            print("Integrity Map:", verify_chain())

        elif choice == "3":
            event_id = input("Enter Event ID: ")
            print(reconstruct_event(event_id))

        elif choice == "4":
            break
