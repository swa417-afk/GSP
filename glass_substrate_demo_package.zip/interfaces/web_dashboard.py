
from flask import Flask, jsonify
from gsp_core.engine import seal_event
from gsp_core.storage import load_chain
from gsp_core.verification import verify_chain

app = Flask(__name__)

@app.route("/seal")
def seal():
    event = seal_event("analyst_42", "HIGH_RISK_QUERY", "HIGH", "v1.0")
    return jsonify(event)

@app.route("/chain")
def chain():
    return jsonify(load_chain())

@app.route("/integrity")
def integrity():
    return jsonify(verify_chain())

if __name__ == "__main__":
    app.run(debug=True)
