
from interfaces.terminal_app import run_terminal

if __name__ == "__main__":
    run_terminal()
